package com.vue;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import com.metier.Region;
import com.persistance.AccesData;

import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import java.awt.Component;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.event.CaretListener;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

import org.jdesktop.swingx.JXTable;

import javax.swing.event.CaretEvent;
import javax.swing.ButtonGroup;
import javax.swing.UIManager;
import javax.swing.JRadioButton;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.Color;

public class PanelConsVis extends JPanel {
	private JLabel lblTitle;
	private JLabel LOGO;
	private JTextField textField_Nom;
	private JTextField textField_id;
	private JScrollPane scrollPane;
	private JXTable table;
	private JTextField textField_Prenom;
	private JRadioButton rdbtnNomPre;
	private JRadioButton rdbtnID;
	private JComboBox comboBox_Region;
	private JRadioButton rdbtnReg;

	/**
	 * Create the panel.
	 */
	public PanelConsVis() {
		setBackground(UIManager.getColor("Desktop.background"));
		setLayout(null);
		add(getLOGO());
		add(getLblTitle());
		add(getTextField_Nom());
		add(getTextField_id());
		add(getComboBox_Region_1());
		add(getRdbtnReg_1());
		add(getRdbtnNomPre());
		add(getRdbtnID());
		add(getScrollPane());
		table.setModel(new ModeleVisiteurs());
		add(getTextField_Prenom());
		
		ButtonGroup bgroup = new ButtonGroup();
		bgroup.add(getRdbtnID());
		bgroup.add(getRdbtnReg_1());
		bgroup.add(getRdbtnNomPre());

	}

	private JLabel getLblTitle() {
		if (lblTitle == null) {
			lblTitle = new JLabel("Consultation Visiteur");
			lblTitle.setForeground(UIManager.getColor("Label.foreground"));
			lblTitle.setBackground(SystemColor.textHighlight);
			lblTitle.setFont(new Font("Arial", Font.BOLD, 14));
			lblTitle.setHorizontalAlignment(SwingConstants.LEFT);
			lblTitle.setBounds(10, 34, 424, 22);
		}
		return lblTitle;
	}
	private JLabel getLOGO() {
		if (LOGO == null) {
			LOGO = new JLabel("GSBFrais");
			LOGO.setLabelFor(this);
			LOGO.setHorizontalAlignment(SwingConstants.CENTER);
			LOGO.setForeground(SystemColor.textHighlight);
			LOGO.setFont(new Font("Tahoma", Font.BOLD, 30));
			LOGO.setBounds(0, 0, 680, 56);
		}
		return LOGO;
	}
	private JTextField getTextField_Nom() {
		if (textField_Nom == null) {
			textField_Nom = new JTextField();
			textField_Nom.setToolTipText("Nom");
			textField_Nom.setEnabled(false);
			textField_Nom.addCaretListener(new CaretListener() {
				public void caretUpdate(CaretEvent e) {
					if(textField_Nom.isEnabled()) {
						table.setModel(new ModeleVisiteurs(null, textField_Nom.getText(), textField_Prenom.getText(), ""));
					 }
				}
			});
			textField_Nom.setBounds(162, 97, 89, 22);
			textField_Nom.setColumns(10);
		}
		return textField_Nom;
	}
	private JTextField getTextField_id() {
		if (textField_id == null) {
			textField_id = new JTextField();
			textField_id.setToolTipText("ID");
			textField_id.setEnabled(false);
			textField_id.setDocument(new LimitJTextField(4));
			textField_id.addCaretListener(new CaretListener() {
				public void caretUpdate(CaretEvent e) {
				 if(textField_id.isEnabled()) {
					 table.setModel(new ModeleVisiteurs(null, "", "", textField_id.getText()));
				 }
				}
			});
			textField_id.setColumns(10);
			textField_id.setBounds(376, 97, 58, 22);
		}
		return textField_id;
	}
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane((Component) null);
			scrollPane.setBounds(10, 140, 652, 174);
			scrollPane.setViewportView(getTable());
		}
		return scrollPane;
	}
	private JTable getTable() {
		if (table == null) {
			table = new JXTable();
			table.setColumnControlVisible(true);
			/* On supprime les traits des lignes et des colonnes */
			table.setShowHorizontalLines(true);
			table.setShowVerticalLines(false);
			table.setRowHeight(50);
			table.packAll();
		}
		return table;
	}
	private JTextField getTextField_Prenom() {
		if (textField_Prenom == null) {
			textField_Prenom = new JTextField();
			textField_Prenom.setToolTipText("Prenom");
			textField_Prenom.setEnabled(false);
			textField_Prenom.addCaretListener(new CaretListener() {
				public void caretUpdate(CaretEvent e) {
					if(textField_Prenom.isEnabled()) {
						table.setModel(new ModeleVisiteurs(null, textField_Nom.getText(), textField_Prenom.getText(), ""));
					}
				}
			});
			textField_Prenom.setColumns(10);
			textField_Prenom.setBounds(261, 97, 96, 22);
		}
		return textField_Prenom;
	}
	
	@SuppressWarnings("unused")
	private void afficheMessage(String message, String title, int type) {
		JOptionPane.showMessageDialog(null, message, title, type);
	}
	
	class LimitJTextField extends PlainDocument 
	{
	   private int max;
	   LimitJTextField(int max) {
	      super();
	      this.max = max;
	   }
	   public void insertString(int offset, String text, AttributeSet attr) throws BadLocationException {
	      if (text == null)
	         return;
	      if ((getLength() + text.length()) <= max) {
	         super.insertString(offset, text, attr);
	      }
	   }
	}
	private JRadioButton getRdbtnNomPre() {
		if (rdbtnNomPre == null) {
			rdbtnNomPre = new JRadioButton("Par nom et prénom");
			rdbtnNomPre.setBounds(162, 67, 196, 23);
			rdbtnNomPre.setForeground(UIManager.getColor("RadioButton.foreground"));
			rdbtnNomPre.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if(rdbtnNomPre.isSelected()) {
						textField_Nom.setEnabled(true);
						textField_Prenom.setEnabled(true);
						table.setModel(new ModeleVisiteurs(null, textField_Nom.getText(), textField_Prenom.getText(), ""));
					} else {
						textField_Nom.setEnabled(false);
						textField_Prenom.setEnabled(false);
						table.setModel(new ModeleVisiteurs(null, "", "", ""));
					}
				}
			});
			rdbtnNomPre.setBackground(UIManager.getColor("RadioButton.background"));
		}
		return rdbtnNomPre;
	}
	private JRadioButton getRdbtnID() {
		if (rdbtnID == null) {
			rdbtnID = new JRadioButton("Par id");
			rdbtnID.setBounds(376, 67, 58, 23);
			rdbtnID.setForeground(UIManager.getColor("RadioButton.foreground"));
			rdbtnID.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if(rdbtnID.isSelected()) {
						textField_id.setEnabled(true);
						table.setModel(new ModeleVisiteurs(null, "", "", textField_id.getText()));
					} else {
						textField_id.setEnabled(false);
						table.setModel(new ModeleVisiteurs(null, "", "", ""));
					}
				}
			});
			rdbtnID.setBackground(UIManager.getColor("RadioButton.background"));
		}
		return rdbtnID;
	}
	private JComboBox getComboBox_Region_1() {
		if (comboBox_Region == null) {
            comboBox_Region = new JComboBox();
            comboBox_Region.setBounds(20, 97, 132, 22);
            for (Region r : AccesData.retrieveRegion()) {
                comboBox_Region.addItem(r.getIdRegion() + " - " + r.getNomRegion());
            }
            comboBox_Region.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if(comboBox_Region.isEnabled()) {
                        table.setModel(new ModeleVisiteurs(comboBox_Region.getSelectedIndex() + 1, "", "", ""));
                     }
                }
            });
        }
        return comboBox_Region;
	}
	private JRadioButton getRdbtnReg_1() {
		if (rdbtnReg == null) {
			rdbtnReg = new JRadioButton("Par region");
			rdbtnReg.setSelected(true);
			rdbtnReg.setForeground(UIManager.getColor("RadioButton.foreground"));
			rdbtnReg.setBackground(UIManager.getColor("RadioButton.background"));
			rdbtnReg.setBounds(20, 67, 128, 23);
			rdbtnReg.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					if(rdbtnReg.isSelected()) {
						comboBox_Region.setEnabled(true);
						table.setModel(new ModeleVisiteurs(comboBox_Region.getSelectedIndex() + 1, "", "", ""));
					} else {
						comboBox_Region.setEnabled(false);
						table.setModel(new ModeleVisiteurs(null, "", "", ""));
					}
				}
			});
		}
		return rdbtnReg;
	}
}
