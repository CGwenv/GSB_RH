package com.vue;

import java.util.List;
import java.util.logging.Level;

import com.metier.Etat;
import com.metier.FicheFrais;
import com.metier.FraisForfait;
import com.metier.LigneFraisForfait;
import com.metier.LigneFraisHorsForfait;
import com.metier.Region;
import com.metier.TypeUtilisateur;
import com.metier.Utilisateur;
import com.metier.Visiteur;
import com.persistance.AccesData;
import com.persistance.HibernateSession;

public class Main {

	public static void main(String[] args) {
		java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.OFF);
		HibernateSession.getSession();
		
		  System.out.println("Etat :");
		  List<Etat> e = AccesData.retrieveEtat();
		  for (Etat es : e) {
		  System.out.println("    "+es.getLibelleEtat());
		  }
		  System.out.println("");

		  System.out.println("Region :");
		  List<Region> r = AccesData.retrieveRegion();
		  for (Region rs : r) {
		  System.out.println("    "+rs.getNomRegion());
		  }
		  System.out.println("");

		  System.out.println("Type Utilisateur :");
		  List<TypeUtilisateur> ty = AccesData.retrieveTypeUtilisateur();
		  for (TypeUtilisateur tys : ty) {
		  System.out.println("    "+tys.getLibelleTypeUtilisateur());
		  }
		  System.out.println("");
		  
		  
		  System.out.println("Frais Forfait :");
		  List<FraisForfait> ff = AccesData.retrieveFraisForfait();
		  for (FraisForfait ffs : ff) {
		  System.out.println("    "+ffs.getLibelleFraisForfait());
		  }
		  System.out.println("");
		  
		  System.out.println("Fiche Frais :");
		  List<FicheFrais> fichef = AccesData.retrieveFicheFrais();
		  for (FicheFrais fichefs : fichef) {
		  System.out.println("    "+fichefs.getEtat());
		  }
		  System.out.println("");
		  
		  System.out.println("Utilisateur :");
		  List<Utilisateur> u = AccesData.retrieveUtilisateur();
		  for (Utilisateur us : u) {
			 System.out.println("    ID : " + us.getIdUtilisateur() + " Login : " + us.getLogin() + " Fiche Frais : " + us.getListeFrais());
		  }
		  System.out.println("");
		  
		  System.out.println("Visiteur :");
		  List<Visiteur> v = AccesData.retrieveVisiteur();
		  for (Visiteur vs : v) {
		  System.out.println("    ID : " + vs.getidVisiteur() + " Login : " + vs.getLogin());
		  }
		  System.out.println("");
		  
		  System.out.println("Ligne Fiche Hors Forfait :");
		  List<LigneFraisHorsForfait> lfhf = AccesData.retrieveLigneFraisHorsForfait();
		  for (LigneFraisHorsForfait lfhfs : lfhf) {
		  System.out.println("    ID Visiteur: " + lfhfs.getIdVisiteur() + " ID Frais : " + lfhfs.getIdFraisHorsForfait());
		  }
		  System.out.println("");
		  
		  System.out.println("Ligne Fiche Forfait :");
		  List<LigneFraisForfait> lff = AccesData.retrieveLigneFraisForfait();
		  for (LigneFraisForfait lffs : lff) {
		  System.out.println("    ID Visiteur: " + lffs.getIdVisiteur() + " ID Frais : " + lffs.getIdFraisForfait());
		  }
		  System.out.println("");
	}

}
