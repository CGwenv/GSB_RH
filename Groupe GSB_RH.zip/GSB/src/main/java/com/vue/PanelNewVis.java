package com.vue;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

public class PanelNewVis extends JPanel {
	private JLabel LOGO;
	private JLabel lblEnregistrerNouveauVisiteur;

	/**
	 * Create the panel.
	 */
	public PanelNewVis() {
		setLayout(null);
		add(getLOGO());
		add(getLblEnregistrerNouveauVisiteur());

	}
	private JLabel getLOGO() {
		if (LOGO == null) {
			LOGO = new JLabel("GSBFrais");
			LOGO.setHorizontalAlignment(SwingConstants.CENTER);
			LOGO.setForeground(SystemColor.textHighlight);
			LOGO.setFont(new Font("Tahoma", Font.BOLD, 30));
			LOGO.setBounds(0, 0, 444, 56);
		}
		return LOGO;
	}
	private JLabel getLblEnregistrerNouveauVisiteur() {
		if (lblEnregistrerNouveauVisiteur == null) {
			lblEnregistrerNouveauVisiteur = new JLabel("Enregistrer nouveau visiteur suite à embauche");
			lblEnregistrerNouveauVisiteur.setHorizontalAlignment(SwingConstants.LEFT);
			lblEnregistrerNouveauVisiteur.setFont(new Font("Arial", Font.BOLD, 14));
			lblEnregistrerNouveauVisiteur.setBackground(SystemColor.textHighlight);
			lblEnregistrerNouveauVisiteur.setBounds(10, 45, 424, 22);
		}
		return lblEnregistrerNouveauVisiteur;
	}
}
