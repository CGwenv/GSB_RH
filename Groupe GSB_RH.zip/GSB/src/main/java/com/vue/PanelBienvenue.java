package com.vue;

import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

public class PanelBienvenue extends JPanel {
	private JLabel LOGO;
	/**
	 * Create the panel.
	 */
	public PanelBienvenue(String nomUtilisateur) {
		setForeground(Color.WHITE);
		setBackground(UIManager.getColor("Desktop.background"));
		setLayout(null);
		JLabel lblBienvenueSurTrisel = new JLabel("Bienvenue, " + nomUtilisateur + " !");
		lblBienvenueSurTrisel.setForeground(UIManager.getColor("Label.foreground"));
		lblBienvenueSurTrisel.setHorizontalAlignment(SwingConstants.CENTER);
		System.out.println("Authentification de l'utilisateur '" + nomUtilisateur + "' !");
		lblBienvenueSurTrisel.setIcon(new ImageIcon("Trisel.jpg"));
		lblBienvenueSurTrisel.setFont(new Font("Calibri", Font.BOLD, 27));
		lblBienvenueSurTrisel.setBounds(0, 57, 690, 181);
		add(lblBienvenueSurTrisel);
		add(getLOGO());
	}
	private JLabel getLOGO() {
		if (LOGO == null) {
			LOGO = new JLabel("GSBFrais");
			LOGO.setHorizontalAlignment(SwingConstants.CENTER);
			LOGO.setForeground(SystemColor.textHighlight);
			LOGO.setFont(new Font("Tahoma", Font.BOLD, 30));
			LOGO.setBounds(0, 0, 690, 56);
		}
		return LOGO;
	}
}
