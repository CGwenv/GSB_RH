package com.vue;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.persistance.HibernateSession;
import com.util.Traitement;

public class MenuConsole {
	/**
	 * Fonction principal du programme
	 * @param args Ne sert pas
	 */
	public static void main(String[] args) {
		Logger.getLogger("org.hibernate").setLevel(Level.OFF);
		HibernateSession.getSession();
		int choix=0;
		
		while (choix!=7)
		{
			System.out.println("████████████████████████████ MENU GENERAL ████████████████████████████");
			System.out.println("█                                                                    █");
			System.out.println("█          1️ - Liste Frais Forfait                                   █");
			System.out.println("█      	   2 - Etat fiche par visiteur                               █");
			System.out.println("█      	   3 - Nombre fiche par visiteur                             █");
			System.out.println("█      	   4 - Stat Fiche frais hors forfait par mois et region      █");
			System.out.println("█      	   5 - Total Fiche frais hors forfait par mois et region     █");
			System.out.println("█      	   6 - Supression d'un visiteur par ID                       █");
			System.out.println("█          7 - Quitter                                               █");
			System.out.println("█                                                                    █");
			System.out.println("██████████████████████████████████████████████████████████████████████");
			System.out.println("▶");
				choix = new Scanner(System.in).nextInt();
				switch (choix) {
				case 1 :
					Traitement.getFicheFrais();
					break;
				case 2 :
					Traitement.getEtatFicheVisiteur();
					break;
				case 3 :
					Traitement.getNbFicheFraisVisiteur();
					break;
				case 4 :
					Traitement.getStatFicheHF();
					break;
				case 5 :
					Traitement.getTotalFicheHF();
					break;
				case 6 :
					Traitement.getSuppVisiteur();
					break;
				default: 
					break;
				}
		}
 
	}
} 