package com.vue.stats;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;

import java.awt.Component;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

import com.metier.Region;
import com.persistance.AccesData;
import com.vue.ModeleVisiteurs;
import com.vue.stats.modele.ModeleVisiteursNBFHFF;

import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Calendar;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.UIManager;

public class StatsNBFicheHorsForfait extends JPanel {
	private JLabel LOGO;
	private JLabel lblStatistiques;
	private JComboBox comboBox_Region;
	private JComboBox comboBox_Mois;
	private JScrollPane scrollPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblMois;

	Date d = new Date();
	private JButton btnNewButton;
	/**
	 * Create the panel.
	 */
	public StatsNBFicheHorsForfait() {
		setBackground(UIManager.getColor("Desktop.background"));
		setLayout(null);
		add(getLOGO());
		add(getLblStatistiques());
		add(getComboBox_Region());
		add(getComboBox_Mois());
		add(getScrollPane());
		table.setModel(new ModeleVisiteurs());
		add(getLblNewLabel());
		add(getLblMois());
		add(getBtnNewButton());

	}

	private JLabel getLOGO() {
		if (LOGO == null) {
			LOGO = new JLabel("GSBFrais");
			LOGO.setBounds(10, 11, 680, 37);
			LOGO.setHorizontalAlignment(SwingConstants.CENTER);
			LOGO.setForeground(SystemColor.textHighlight);
			LOGO.setFont(new Font("Tahoma", Font.BOLD, 30));
		}
		return LOGO;
	}
	private JLabel getLblStatistiques() {
		if (lblStatistiques == null) {
			lblStatistiques = new JLabel("Nombre de fiche frais hors forfait");
			lblStatistiques.setForeground(UIManager.getColor("Label.foreground"));
			lblStatistiques.setHorizontalAlignment(SwingConstants.LEFT);
			lblStatistiques.setFont(new Font("Arial", Font.BOLD, 14));
			lblStatistiques.setBackground(SystemColor.textHighlight);
			lblStatistiques.setBounds(10, 40, 424, 22);
		}
		return lblStatistiques;
	}
	private JComboBox getComboBox_Region() {
		if (comboBox_Region == null) {
			comboBox_Region = new JComboBox();
			comboBox_Region.setBounds(67, 73, 139, 22);
			for (Region r : AccesData.retrieveRegion()) {
				comboBox_Region.addItem(r.getIdRegion() + " - " + r.getNomRegion());
			}
		}
		return comboBox_Region;
	}
	private JComboBox getComboBox_Mois() {
		if (comboBox_Mois == null) {
			comboBox_Mois = new JComboBox();
			comboBox_Mois.setBounds(252, 73, 95, 22);
			for (Month m : Month.values()) {
				getComboBox_Mois().addItem(m.getDisplayName(TextStyle.FULL, getLocale()));
			}
			comboBox_Mois.removeItemAt(d.getMonth());
		}
		return comboBox_Mois;
	}
	
	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane((Component) null);
			scrollPane.setBounds(10, 106, 670, 208);
			scrollPane.setViewportView(getTable());
		}
		return scrollPane;
	}
	private JTable getTable() {
		if (table == null) {
			table = new JTable();
			
		}
		return table;
	}
	
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Région :");
			lblNewLabel.setForeground(UIManager.getColor("Label.foreground"));
			lblNewLabel.setBounds(20, 73, 47, 22);
		}
		return lblNewLabel;
	}
	private JLabel getLblMois() {
		if (lblMois == null) {
			lblMois = new JLabel("Mois :");
			lblMois.setForeground(UIManager.getColor("Label.foreground"));
			lblMois.setBounds(216, 73, 37, 22);
		}
		return lblMois;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("GO");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					getTable().setModel(new ModeleVisiteursNBFHFF(getComboBox_Region().getSelectedIndex() ,String.valueOf(d.getYear()+1900) + String.format("%02d", (getComboBox_Mois().getSelectedIndex()+1))));
				}
			});
			btnNewButton.setBounds(357, 73, 77, 23);
		}
		return btnNewButton;
	}
}
