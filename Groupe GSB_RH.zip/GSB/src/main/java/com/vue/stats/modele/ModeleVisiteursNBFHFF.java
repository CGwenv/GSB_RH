package com.vue.stats.modele;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;
import com.persistance.AccesData;

public class ModeleVisiteursNBFHFF extends AbstractTableModel {
private String[] entetes = { "Nom", "Prénom", "Nb de fiche hors forfait"};
	private List<Object[]> listeVisiteur;

	public ModeleVisiteursNBFHFF(int idRegion, String mois) { 
		listeVisiteur = AccesData.GetStatFicheHF(idRegion,mois);
		if(listeVisiteur.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Aucun visiteur", "Erreur de suppresion", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public ModeleVisiteursNBFHFF() { 
		listeVisiteur = AccesData.getVisiteur();
	}

	@Override
	public int getRowCount() { return listeVisiteur.size(); }

	@Override
	public int getColumnCount() { return entetes.length; }

	@Override
	public String getColumnName(int columnIndex) { return entetes[columnIndex]; }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return listeVisiteur.get(rowIndex)[1];
		case 1:
			return listeVisiteur.get(rowIndex)[2];
		case 2:
			return listeVisiteur.get(rowIndex)[3];
		default:
			throw new IllegalArgumentException();
		}
	}
}