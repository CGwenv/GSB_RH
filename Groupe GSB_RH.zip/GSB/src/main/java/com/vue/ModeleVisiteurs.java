package com.vue;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import com.persistance.AccesData;

public class ModeleVisiteurs extends AbstractTableModel {
private String[] entetes = { "idVisiteur", "Nom", "Prénom"};
	private List<Object[]> listeVisiteur;

	public ModeleVisiteurs(Integer reg, String nom, String prenom, String id) { 
		
		listeVisiteur = AccesData.getVisiteur();
		
		if(reg != null) {
			listeVisiteur = AccesData.getVisiteurRegion(reg);
		}
		
		if(!nom.isEmpty() && !prenom.isEmpty()) {
			listeVisiteur = AccesData.getVisiteurNomPrenom(nom, prenom);
		}
		
		if(!id.isEmpty()) {
			listeVisiteur = AccesData.getVisiteurID(id);
		}
		
	}
	
	public ModeleVisiteurs() { 
		listeVisiteur = AccesData.getVisiteur();
	}

	@Override
	public int getRowCount() { return listeVisiteur.size(); }

	@Override
	public int getColumnCount() { return entetes.length; }

	@Override
	public String getColumnName(int columnIndex) { return entetes[columnIndex]; }

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		switch (columnIndex) {
		case 0:
			return listeVisiteur.get(rowIndex)[0];
		case 1:
			return listeVisiteur.get(rowIndex)[1];
		case 2:
			return listeVisiteur.get(rowIndex)[2];
		default:
			throw new IllegalArgumentException();
		}
	}
}