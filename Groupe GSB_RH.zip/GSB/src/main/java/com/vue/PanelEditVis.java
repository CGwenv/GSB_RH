package com.vue;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.SwingConstants;

import com.metier.Region;
import com.metier.Visiteur;
import com.persistance.AccesData;

import javax.swing.JComboBox;
import javax.swing.UIManager;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelEditVis extends JPanel {
	private JLabel LOGO;
	private JLabel lblModificationVisiteur;
	private JComboBox comboBox_Visiteur;
	private JLabel lblSelect;
	private JPanel panel;
	private JButton btnApply;
	private JLabel lblAdresse;
	private JTextField textFieldAdr;
	private JTextField textFieldCP;
	private JTextField textFieldVille;
	private JComboBox comboBox_Region;
	private JLabel lblNewLabel;
	private JTextField textField_TelFixe;
	private JTextField textField_TelPort;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_1_1;
	
	Visiteur v;

	/**
	 * Create the panel.
	 */
	public PanelEditVis() {
		setBackground(UIManager.getColor("Desktop.background"));
		setLayout(null);
		add(getLOGO());
		add(getLblModificationVisiteur());
		add(getComboBox_Visiteur());
		add(getLblSelect());
		add(getPanel());

	}
	private JLabel getLOGO() {
		if (LOGO == null) {
			LOGO = new JLabel("GSBFrais");
			LOGO.setHorizontalAlignment(SwingConstants.CENTER);
			LOGO.setForeground(SystemColor.textHighlight);
			LOGO.setFont(new Font("Tahoma", Font.BOLD, 30));
			LOGO.setBounds(0, 0, 690, 37);
		}
		return LOGO;
	}
	private JLabel getLblModificationVisiteur() {
		if (lblModificationVisiteur == null) {
			lblModificationVisiteur = new JLabel("Modification Visiteur");
			lblModificationVisiteur.setForeground(UIManager.getColor("Label.foreground"));
			lblModificationVisiteur.setHorizontalAlignment(SwingConstants.LEFT);
			lblModificationVisiteur.setFont(new Font("Arial", Font.BOLD, 14));
			lblModificationVisiteur.setBackground(SystemColor.textHighlight);
			lblModificationVisiteur.setBounds(10, 26, 424, 22);
		}
		return lblModificationVisiteur;
	}
	private JComboBox getComboBox_Visiteur() {
		if (comboBox_Visiteur == null) {
			comboBox_Visiteur = new JComboBox();
			comboBox_Visiteur.setFont(new Font("Tahoma", Font.PLAIN, 25));
			comboBox_Visiteur.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String[] idVisiteur = comboBox_Visiteur.getSelectedItem().toString().split("-"); 
					v = AccesData.retriveVisiteurByID(idVisiteur[0]);
					
					
					// Tél Fixe et Portable
					getTextField_TelFixe().setText(v.getTelFixe());
					getTextField_TelPort().setText(v.getTelPortable());
					
					//Adresse
					getTextFieldAdr().setText(v.getAdresse());
					getTextFieldCP().setText(v.getCp());
					getTextFieldVille().setText(v.getVille());
					
					getComboBox_Region().setSelectedIndex(v.getIDRegion());
				}
			});
			comboBox_Visiteur.setBounds(207, 45, 456, 44);
			for (Visiteur v : AccesData.retrieveVisiteur()) {
				getComboBox_Visiteur().addItem(v.getidVisiteur() + " - " + v.getNom() + " " + v.getPrenom());
			}
		}
		return comboBox_Visiteur;
	}
	private JLabel getLblSelect() {
		if (lblSelect == null) {
			lblSelect = new JLabel("Selectionnez un visiteur : ");
			lblSelect.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
			lblSelect.setForeground(UIManager.getColor("Label.foreground"));
			lblSelect.setBounds(20, 48, 187, 41);
		}
		return lblSelect;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(UIManager.getColor("CheckBox.light"));
			panel.setBounds(10, 100, 653, 214);
			panel.setLayout(null);
			panel.add(getBtnApply());
			panel.add(getLblAdresse());
			panel.add(getTextFieldAdr());
			panel.add(getTextFieldCP());
			panel.add(getTextFieldVille());
			panel.add(getComboBox_Region());
			panel.add(getLblNewLabel());
			panel.add(getTextField_TelFixe());
			panel.add(getTextField_TelPort());
			panel.add(getLblNewLabel_1());
			panel.add(getLblNewLabel_1_1());
		}
		return panel;
	}
	private JButton getBtnApply() {
		if (btnApply == null) {
			btnApply = new JButton("Appliquer");
			btnApply.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(!getTextFieldAdr().getText().isEmpty() && !getTextFieldCP().getText().isEmpty() && !getTextFieldVille().getText().isEmpty() && !getTextField_TelFixe().getText().isEmpty() && !getTextField_TelPort().getText().isEmpty()) {
					int reponse = JOptionPane.showConfirmDialog(null, "Êtes vous sur de vouloir modifié le visiteur '"+v.getidVisiteur()+"' ?", "Etiquettes Java", JOptionPane.YES_NO_OPTION);
					if(reponse == JOptionPane.YES_OPTION) {
						System.out.println("Modification du visiteur " + v.getidVisiteur());
					try {
						AccesData.updateVisiteur(v.getidVisiteur(), getTextFieldAdr().getText(), getTextFieldCP().getText(), getTextFieldVille().getText(), getTextField_TelFixe().getText(), getTextField_TelPort().getText(), getComboBox_Region().getSelectedIndex());
						v.setAdresse(getTextFieldAdr().getText());
						v.setCp(getTextFieldCP().getText());
						v.setVille(getTextFieldVille().getText());
						v.setTelFixe(getTextField_TelFixe().getText());
						v.setTelPortable(getTextField_TelPort().getText());
						JOptionPane.showMessageDialog(null, "Le visiteur '" + v.getidVisiteur() + "' a bien été modifié !", "Modification OK", JOptionPane.INFORMATION_MESSAGE);
					}catch (Exception e1) {
						System.out.println(e1.getLocalizedMessage());
						JOptionPane.showMessageDialog(null, e1.getLocalizedMessage(), "Erreur de modification", JOptionPane.ERROR_MESSAGE);
					}
					}
					} else {
						JOptionPane.showMessageDialog(null, "Veuillez remplir tout les champs !", "Erreur de modification", JOptionPane.ERROR_MESSAGE);
					}
					
					
				}
			});
			btnApply.setForeground(UIManager.getColor("Button.highlight"));
			btnApply.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
			btnApply.setFont(new Font("Tahoma", Font.BOLD, 20));
			btnApply.setBounds(448, 164, 193, 39);
		}
		return btnApply;
	}
	private JLabel getLblAdresse() {
		if (lblAdresse == null) {
			lblAdresse = new JLabel("Adresse : ");
			lblAdresse.setFont(new Font("Tahoma", Font.BOLD, 15));
			lblAdresse.setForeground(UIManager.getColor("Label.foreground"));
			lblAdresse.setBounds(10, 14, 89, 38);
		}
		return lblAdresse;
	}
	private JTextField getTextFieldAdr() {
		if (textFieldAdr == null) {
			textFieldAdr = new JTextField();
			textFieldAdr.setFont(new Font("Tahoma", Font.PLAIN, 20));
			textFieldAdr.setColumns(10);
			textFieldAdr.setBounds(109, 11, 536, 41);
		}
		return textFieldAdr;
	}
	private JTextField getTextFieldCP() {
		if (textFieldCP == null) {
			textFieldCP = new JTextField();
			textFieldCP.setFont(new Font("Tahoma", Font.PLAIN, 20));
			textFieldCP.setColumns(10);
			textFieldCP.setBounds(109, 59, 123, 41);
		}
		return textFieldCP;
	}
	private JTextField getTextFieldVille() {
		if (textFieldVille == null) {
			textFieldVille = new JTextField();
			textFieldVille.setFont(new Font("Tahoma", Font.PLAIN, 20));
			textFieldVille.setColumns(10);
			textFieldVille.setBounds(242, 59, 399, 41);
		}
		return textFieldVille;
	}
	private JComboBox getComboBox_Region() {
		if (comboBox_Region == null) {
			comboBox_Region = new JComboBox();
			comboBox_Region.setFont(new Font("Tahoma", Font.PLAIN, 20));
			comboBox_Region.setBounds(109, 164, 309, 39);
			
			for (Region r : AccesData.retrieveRegion()) {
				getComboBox_Region().addItem(r.getIdRegion() + " - " + r.getNomRegion());
			}
		}
		return comboBox_Region;
	}
	private JLabel getLblNewLabel() {
		if (lblNewLabel == null) {
			lblNewLabel = new JLabel("Région :");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
			lblNewLabel.setForeground(UIManager.getColor("Label.foreground"));
			lblNewLabel.setBounds(10, 164, 75, 39);
		}
		return lblNewLabel;
	}
	private JTextField getTextField_TelFixe() {
		if (textField_TelFixe == null) {
			textField_TelFixe = new JTextField();
			textField_TelFixe.setFont(new Font("Tahoma", Font.PLAIN, 20));
			textField_TelFixe.setBounds(109, 111, 186, 42);
			textField_TelFixe.setColumns(10);
		}
		return textField_TelFixe;
	}
	private JTextField getTextField_TelPort() {
		if (textField_TelPort == null) {
			textField_TelPort = new JTextField();
			textField_TelPort.setFont(new Font("Tahoma", Font.PLAIN, 20));
			textField_TelPort.setColumns(10);
			textField_TelPort.setBounds(416, 111, 179, 42);
		}
		return textField_TelPort;
	}
	private JLabel getLblNewLabel_1() {
		if (lblNewLabel_1 == null) {
			lblNewLabel_1 = new JLabel("Tél Fixe :");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
			lblNewLabel_1.setForeground(UIManager.getColor("Label.foreground"));
			lblNewLabel_1.setBounds(10, 111, 75, 42);
		}
		return lblNewLabel_1;
	}
	private JLabel getLblNewLabel_1_1() {
		if (lblNewLabel_1_1 == null) {
			lblNewLabel_1_1 = new JLabel("Portable :");
			lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 15));
			lblNewLabel_1_1.setForeground(UIManager.getColor("Label.foreground"));
			lblNewLabel_1_1.setBounds(317, 111, 89, 42);
		}
		return lblNewLabel_1_1;
	}
}
