package com.vue;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jdesktop.swingx.JXButton;

import com.persistance.AccesData;
import com.persistance.HibernateSession;
import com.vue.stats.StatsNBFicheHorsForfait;


import com.formdev.flatlaf.FlatLightLaf;
import com.metier.ASCIIArtGenerator;
import com.metier.TypeUtilisateur;
import com.metier.Utilisateur;

import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import java.awt.SystemColor;
import javax.swing.UIManager;

import java.awt.Toolkit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdesktop.swingx.JXImagePanel;

public class MenuPrin extends JFrame{

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnMenu;
	private JMenuItem mntmDeconnexion;
	private JMenuItem mntmQuitter;
	private JPanel panelAuthentification;
	private JLabel lblLogin;
	private JLabel lblMotDePasse;
	private JTextField textField_Username;
	private JPasswordField passwordField;
	private static JXButton btnValider;
	private JMenu mnVisiteur;
	private JMenuItem mntmConsVis;
	private JMenuItem mntmNewVis;
	private JMenuItem mntmEditVis;
	private JMenuItem mntmDelVis;
	private JMenu mnStats;
	private JMenu mnFraisHF;
	private JMenu mnFraisForfait;
	private JMenuItem mntmNbHFVis;
	private JMenuItem mntmMontHFVis;
	private JMenuItem mntmMoyMontRegHF;
	private JMenuItem mntmMontVisFF;
	private JMenuItem mntmMontRegFF;
	private JXImagePanel imagePanel;

	/**
	 * Lancement de l'application
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					/**
					 * Génération de l'ASCII Art GSB Client Lourd
					 */
					ASCIIArtGenerator artGen = new ASCIIArtGenerator();
					System.out.println(" ");
					artGen.printTextArt("GSB Client Lourd", ASCIIArtGenerator.ART_SIZE_EXTRASMALL);
					
					/**
					 * Initilatisation de la connexion à la base de données
					 */
					Logger.getLogger("org.hibernate").setLevel(Level.OFF);
					System.out.println(" ");
					System.out.println("█████████████ Base de données █████████████");
					System.out.println("█                                         █");
					System.out.println("█   Chargement de la base de données...   █");
					if(HibernateSession.getSession() != null) {
						System.out.println("█         Base de données chargée !       █");
					}
					System.out.println("█                                         █");
					System.out.println("███████████████████████████████████████████");
					System.out.println(" ");
					
					/**
					 * Application du thème de l'application
					 */
					System.out.println("██████████████████ Thème ██████████████████");
					System.out.println("█                                         █");
					System.out.println("█          Chargement du thème...         █");
					FlatLightLaf.setup();
					UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
					System.out.println("█              Thème chargé !             █");
					System.out.println("█                                         █");
					System.out.println("███████████████████████████████████████████");
					
					/**
					 * Création et Affichage de la fenètre principale
					 */
					MenuPrin frame = new MenuPrin();
					frame.setVisible(true);
					frame.getRootPane().setDefaultButton(btnValider);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Création de la fenètre.
	 */
	public MenuPrin() {
		/**
		 * Création des objets et Configuration de la fenètre
		 */
		setResizable(false);
		setForeground(SystemColor.textHighlight);
		setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("GSB.png")));
		setTitle("GSB Client Lourd");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 376);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		contentPane.add(getPanelAuthentification());
		desactivationItemMenu();
	}
	
	/**
	 * Méthode de désactivation des menus
	 */
	public void desactivationItemMenu() {
		mntmDeconnexion.setEnabled(false);
	}

	/**
	 * Création de la barre de menu
	 * @return JMenuBar
	 */
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.setBackground(Color.WHITE);
			menuBar.add(getMnMenu());
			
			menuBar.add(getMnStats());
		}
		return menuBar;
	}
	
	/**
	 * Ajout d'un menu Fichier dans la barre de menu
	 * @return JMenu
	 */
	private JMenu getMnMenu() {
		if (mnMenu == null) {
			mnMenu = new JMenu("Fichier");
			mnMenu.setForeground(Color.BLACK);
			mnMenu.add(getMntmDeconnexion());
			mnMenu.add(getMntmQuitter());
			
		}
		return mnMenu;
	}
	
	/**
	 * Ajout d'un sous menu Déconnexion dans la barre de menu
	 * @return JMenuItem
	 */
	private JMenuItem getMntmDeconnexion() {
		if (mntmDeconnexion == null) {
			mntmDeconnexion = new JMenuItem("Déconnexion");
			mntmDeconnexion.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					auth();
				}
			});
		}
		return mntmDeconnexion;
	}
	
	// Méthode auth pour affichage du menu de connexion
	private void auth() {
		// Désactivation des menus
		desactivationItemMenu();
		// on affecte le panel de la fenêtre
		// avec une instance de PanelEditionfacture
		this.setContentPane(getPanelAuthentification());
		// mets à jour le formulaire
		this.revalidate();
		// vidage des champs du formulaire
		clear();
		// focus sur le champs login
		textField_Username.requestFocus();
	}
	
	/**
	 * Méthode bienvenue pour affichage panel de bienvenue (Fond Ecran)
	 * @param login
	 */
	private void bienvenue(String login) {
		// on affecte le panel de la fenêtre
		// avec une instance de PanelEditionfacture
		this.setContentPane(new PanelBienvenue(login));
		// mets à jour le formulaire
		this.revalidate();
	}
	
	/**
	 * Méthode de vidage des champs
	 */
	public void clear() {
		textField_Username.setText(null);
		passwordField.setText(null);
	}
	
	/**
	 * Ajout d'un sous menu Quitter dans la barre de menu
	 * @return JMenuItem
	 */
	private JMenuItem getMntmQuitter() {
		if (mntmQuitter == null) {
			mntmQuitter = new JMenuItem("Quitter");
			mntmQuitter.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					System.exit(EXIT_ON_CLOSE);
				}
			});
		}
		return mntmQuitter;
	}
	
	/**
	 * Ajout d'un Panel d'authentification
	 * @return JPanel
	 */
	private JPanel getPanelAuthentification() {
		if (panelAuthentification == null) {
			panelAuthentification = new JPanel();
			panelAuthentification.setLayout(null);
			panelAuthentification.setBackground(UIManager.getColor("Desktop.background"));
			panelAuthentification.setBounds(0, 0, 690, 325);
			panelAuthentification.add(getLblLogin());
			panelAuthentification.add(getLblMotDePasse());
			panelAuthentification.add(getTextField_Username());
			panelAuthentification.add(getPasswordField());
			panelAuthentification.add(getBtnValider());
			panelAuthentification.add(getImagePanel());
		}
		return panelAuthentification;
	}
	
	/**
	 * Ajout d'un libelle Login
	 * @return JLabel
	 */
	private JLabel getLblLogin() {
		if (lblLogin == null) {
			lblLogin = new JLabel("Login :");
			lblLogin.setBackground(Color.WHITE);
			lblLogin.setForeground(UIManager.getColor("Label.foreground"));
			lblLogin.setFont(new Font("Arial", Font.BOLD, 16));
			lblLogin.setBounds(198, 115, 123, 35);
		}
		return lblLogin;
	}
	
	/**
	 * Ajout d'un libelle Mot de passe
	 * @return JLabel
	 */
	private JLabel getLblMotDePasse() {
		if (lblMotDePasse == null) {
			lblMotDePasse = new JLabel("Mot de passe :");
			lblMotDePasse.setForeground(UIManager.getColor("Label.foreground"));
			lblMotDePasse.setFont(new Font("Arial", Font.BOLD, 16));
			lblMotDePasse.setBounds(198, 164, 123, 35);
		}
		return lblMotDePasse;
	}
	
	/**
	 * Ajout d'un champ pour la saisie du nom d'utilisateur
	 * @return JTextField
	 */
	private JTextField getTextField_Username() {
		if (textField_Username == null) {
			textField_Username = new JTextField();
			textField_Username.setFont(new Font("Arial", Font.BOLD, 18));
			textField_Username.setColumns(10);
			textField_Username.setBounds(326, 115, 173, 38);
		}
		return textField_Username;
	}
	
	/**
	 * Ajout d'un champ pour la saisie du mot de passe
	 * @return JPasswordField
	 */
	private JPasswordField getPasswordField() {
		if (passwordField == null) {
			passwordField = new JPasswordField();
			passwordField.setFont(new Font("Arial", Font.BOLD, 18));
			passwordField.setBounds(326, 161, 173, 38);
		}
		return passwordField;
	}
	
	/**
	 * Ajout d'un bouton pour valider le formulaire de connexion
	 * @return JButton
	 */
	private JButton getBtnValider() {
		if (btnValider == null) {
			btnValider = new JXButton("CONNEXION");
			btnValider.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// Récupération des données saisies
					String login = textField_Username.getText();
					String mdp = String.copyValueOf(passwordField.getPassword());
					// Récupération de l'utilisateur dans la base
					Utilisateur util = AccesData.getUtilisateur(login, mdp);
					// Test d'existence
					if (util != null) {
						// Activation menuItem en fonction du niveau
						paramType(util.getUnTypeUtilisateur());
						bienvenue(util.getLogin());
					} else {
						// Affichage message
						System.out.println("Echec de la connexion");
						afficheMessage("Nom d'utilisateur ou mot de passe incorrect !", "Erreur d'authentification", JOptionPane.ERROR_MESSAGE);
					}
				}
			});
			btnValider.setForeground(SystemColor.text);
			btnValider.setBackground(SystemColor.textHighlight);
			btnValider.setFont(new Font("Arial", Font.BOLD, 20));
			btnValider.setBounds(198, 210, 301, 56);
		}
		return btnValider;
	}
	
	
	/**
	 * Affichage des menus en fonction du niveau de permissions d'un Utilisateur
	 * @param typeUtilisateur
	 */
	public void paramType(TypeUtilisateur typeUtilisateur) {
		mntmDeconnexion.setEnabled(true);
		switch (typeUtilisateur.getIdTypeUtilisateur()) {
		case "DR": {
			menuBar.add(getMnVisiteur());
			break;
		}
		case "S": {
			menuBar.add(getMnVisiteur());
			break;
		}
		case "R": {
			menuBar.add(getMnStats());
			break;
		}
		default:
			break;
		}
	}

	/**
	 * Fonction permetant la génération d'une boite de dialogue
	 * @param message
	 * @param title
	 * @param type
	 */
	private void afficheMessage(String message, String title, int type) {
		JOptionPane.showMessageDialog(null, message, title, type);
	}
	
	/**
	 * Création du menu "Visiteur"
	 * @return JMenu
	 */
	private JMenu getMnVisiteur() {
		if (mnVisiteur == null) {
			mnVisiteur = new JMenu("Visiteur");
			mnVisiteur.setForeground(SystemColor.text);
			mnVisiteur.add(getMntmConsVis());
			mnVisiteur.add(getMntmNewVis());
			mnVisiteur.add(getMntmEditVis());
			mnVisiteur.add(getMntmDelVis());
		}
		return mnVisiteur;
	}
	
	/**
	 * Création d'un sous menu "Consultation" dans le menu "Visiteur"
	 * @return JMenuItem
	 */
	private JMenuItem getMntmConsVis() {
		if (mntmConsVis == null) {
			mntmConsVis = new JMenuItem("Consultation");
			mntmConsVis.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					consultationVisiteur();
				}
			});
		}
		return mntmConsVis;
	}
	
	/**
	 * Action du sous menu "Visiteur->Consultation"
	 */
	private void consultationVisiteur() {
		// on affecte le panel de la fenêtre
		// avec une instance de PanelHabParUsager
		this.setContentPane(new PanelConsVis());
		// mets à jour le formulaire
		this.revalidate();
	}
	
	/**
	 * Création d'un sous menu "Ajout" dans le menu "Visiteur"
	 * @return JMenuItem
	 */
	private JMenuItem getMntmNewVis() {
		if (mntmNewVis == null) {
			mntmNewVis = new JMenuItem("Ajout");
			mntmNewVis.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					ajoutVisiteur();
				}
			});
		}
		return mntmNewVis;
	}
	
	/**
	 * Action du sous menu "Visiteur->Ajout"
	 */
	private void ajoutVisiteur() {
		// on affecte le panel de la fenêtre
		// avec une instance de PanelHabParUsager
		this.setContentPane(new PanelNewVis());
		// mets à jour le formulaire
		this.revalidate();
	}
	
	/**
	 * Création d'un sous menu "Modifi Coord" dans le menu "Visiteur"
	 * @return JMenuItem
	 */
	private JMenuItem getMntmEditVis() {
		if (mntmEditVis == null) {
			mntmEditVis = new JMenuItem("Modifi Coord");
			mntmEditVis.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					editVisiteur();
				}
			});
		}
		return mntmEditVis;
	}
	
	/**
	 * Action du sous menu "Visiteur->Modifi Coord"
	 */
	private void editVisiteur() {
		// on affecte le panel de la fenêtre
		// avec une instance de PanelHabParUsager
		this.setContentPane(new PanelEditVis());
		// mets à jour le formulaire
		this.revalidate();
	}
	
	/**
	 * Création d'un sous menu "Suppresion" dans le menu "Visiteur"
	 * @return JMenuItem
	 */
	private JMenuItem getMntmDelVis() {
		if (mntmDelVis == null) {
			mntmDelVis = new JMenuItem("Suppresion");
			mntmDelVis.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					delVisiteur();
				}
			});
		}
		return mntmDelVis;
	}
	
	/**
	 * Action du sous menu "Visiteur->Suppresion"
	 */
	private void delVisiteur() {
		// on affecte le panel de la fenêtre
		// avec une instance de PanelHabParUsager
		this.setContentPane(new PanelDelVis());
		// mets à jour le formulaire
		this.revalidate();
	}
	
	
	/**
	 * Création du menu "Statistiques"
	 * @return JMenu
	 */
	private JMenu getMnStats() {
		if (mnStats == null) {
			mnStats = new JMenu("Statistiques");
			mnStats.setForeground(Color.BLACK);
			mnStats.add(getMnFraisHF());
			mnStats.add(getMnFraisForfait());
		}
		return mnStats;
	}
	
	/**
	 * Création du menu "Frais Hors Forfait" dans le menu "Statistiques"
	 * @return JMenu
	 */
	private JMenu getMnFraisHF() {
		if (mnFraisHF == null) {
			mnFraisHF = new JMenu("Frais Hors Forfait");
			mnFraisHF.add(getMntmNbHFVis());
			mnFraisHF.add(getMntmMontHFVis());
			mnFraisHF.add(getMntmMoyMontRegHF());
		}
		return mnFraisHF;
	}
	
	/**
	 * Création du menu "Frais Forfait" dans le menu "Statistiques"
	 * @return JMenu
	 */
	private JMenu getMnFraisForfait() {
		if (mnFraisForfait == null) {
			mnFraisForfait = new JMenu("Frais Forfait");
			mnFraisForfait.add(getMntmMontVisFF());
			mnFraisForfait.add(getMntmMontRegFF());
		}
		return mnFraisForfait;
	}
	
	private JMenuItem getMntmNbHFVis() {
		if (mntmNbHFVis == null) {
			mntmNbHFVis = new JMenuItem("Nombre par région mois");
			mntmNbHFVis.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					stats_NBFFHFparRegMois();
				}
			});
		}
		return mntmNbHFVis;
	}
	
	/**
	 * Action du sous menu "Statistiques->Nombre par région mois"
	 */
	private void stats_NBFFHFparRegMois() {
		// on affecte le panel de la fenêtre
		// avec une instance de PanelHabParUsager
		this.setContentPane(new StatsNBFicheHorsForfait());
		// mets à jour le formulaire
		this.revalidate();
	}
	
	private JMenuItem getMntmMontHFVis() {
		if (mntmMontHFVis == null) {
			mntmMontHFVis = new JMenuItem("Montant par visiteur");
		}
		return mntmMontHFVis;
	}
	private JMenuItem getMntmMoyMontRegHF() {
		if (mntmMoyMontRegHF == null) {
			mntmMoyMontRegHF = new JMenuItem("Moyenne montant region");
		}
		return mntmMoyMontRegHF;
	}
	private JMenuItem getMntmMontVisFF() {
		if (mntmMontVisFF == null) {
			mntmMontVisFF = new JMenuItem("Montant par visiteur");
		}
		return mntmMontVisFF;
	}
	private JMenuItem getMntmMontRegFF() {
		if (mntmMontRegFF == null) {
			mntmMontRegFF = new JMenuItem("Montant par région");
		}
		return mntmMontRegFF;
	}
	
	/**
	 * Ajout du logo GSB sur le JPanel
	 * @return JXImagePanel
	 */
	private JXImagePanel getImagePanel() {
		if (imagePanel == null) {
			imagePanel = new JXImagePanel();
			imagePanel.setBounds(0, 11, 690, 93);
			try {
				imagePanel.setImage(ImageIO.read(getClass().getClassLoader().getResource("GSB - Copie.png")));
				imagePanel.setStyle(JXImagePanel.Style.SCALED_KEEP_ASPECT_RATIO);
				imagePanel.setBackground(null);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return imagePanel;
	}
}
