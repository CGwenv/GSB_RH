package com.vue;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import javax.swing.UIManager;

import com.metier.Visiteur;
import com.persistance.AccesData;

import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelDelVis extends JPanel {
	private JLabel LOGO;
	private JLabel lblSuppressionDunVisiteur;
	private JPanel panel;
	private JLabel lblSelect;
	private JComboBox comboBox_Visiteur;
	private JButton btnNewButton;
	
	Visiteur v;

	/**
	 * Create the panel.
	 */
	public PanelDelVis() {
		setLayout(null);
		add(getLOGO());
		add(getLblSuppressionDunVisiteur());
		add(getPanel());
	}
	private JLabel getLOGO() {
		if (LOGO == null) {
			LOGO = new JLabel("GSBFrais");
			LOGO.setHorizontalAlignment(SwingConstants.CENTER);
			LOGO.setForeground(SystemColor.textHighlight);
			LOGO.setFont(new Font("Tahoma", Font.BOLD, 30));
			LOGO.setBounds(0, 0, 444, 56);
		}
		return LOGO;
	}
	private JLabel getLblSuppressionDunVisiteur() {
		if (lblSuppressionDunVisiteur == null) {
			lblSuppressionDunVisiteur = new JLabel("Suppression d'un visiteur qui quitte l'entreprise");
			lblSuppressionDunVisiteur.setHorizontalAlignment(SwingConstants.LEFT);
			lblSuppressionDunVisiteur.setFont(new Font("Arial", Font.BOLD, 14));
			lblSuppressionDunVisiteur.setBackground(SystemColor.textHighlight);
			lblSuppressionDunVisiteur.setBounds(10, 45, 424, 22);
		}
		return lblSuppressionDunVisiteur;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(UIManager.getColor("CheckBox.light"));
			panel.setBounds(10, 67, 655, 140);
			panel.setLayout(null);
			panel.add(getLblSelect());
			panel.add(getComboBox_Visiteur());
			panel.add(getBtnNewButton());
		}
		return panel;
	}
	private JLabel getLblSelect() {
		if (lblSelect == null) {
			lblSelect = new JLabel("Sélectionnez un visiteur : ");
			lblSelect.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 15));
			lblSelect.setBounds(10, 11, 222, 40);
		}
		return lblSelect;
	}
	private JComboBox getComboBox_Visiteur() {
		if (comboBox_Visiteur == null) {
			comboBox_Visiteur = new JComboBox();
			comboBox_Visiteur.setFont(new Font("Arial", Font.PLAIN, 20));
			comboBox_Visiteur.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(comboBox_Visiteur.getItemCount() != 0) {
						String[] idVisiteur = comboBox_Visiteur.getSelectedItem().toString().split("-"); 
						v = AccesData.retriveVisiteurByID(idVisiteur[0]);
					}
				}
			});
			comboBox_Visiteur.setBounds(242, 11, 403, 40);
			for (Visiteur v : AccesData.retrieveVisiteur()) {
				comboBox_Visiteur.addItem(v.getidVisiteur() + " - " + v.getNom() + " " + v.getPrenom());
			}
		}
		return comboBox_Visiteur;
	}
	private JButton getBtnNewButton() {
		if (btnNewButton == null) {
			btnNewButton = new JButton("SUPPRIMER");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					int reponse = JOptionPane.showConfirmDialog(null, "Êtes vous sur de vouloir supprimé le visiteur '"+v.getidVisiteur()+"' ?", "Etiquettes Java", JOptionPane.YES_NO_OPTION);
					if(reponse == JOptionPane.YES_OPTION) {
						System.out.println("Supression du visiteur " + v.getidVisiteur());
						AccesData.removeVisiteurByID(v.getidVisiteur());
						getComboBox_Visiteur().removeAllItems();
						for (Visiteur v : AccesData.retrieveVisiteur()) {
							getComboBox_Visiteur().addItem(v.getidVisiteur() + " - " + v.getNom() + " " + v.getPrenom());
						}
						getComboBox_Visiteur().setSelectedIndex(0);
					}
				}
			});
			btnNewButton.setFont(new Font("Arial", Font.BOLD, 17));
			btnNewButton.setForeground(new Color(255, 255, 255));
			btnNewButton.setBackground(new Color(204, 51, 0));
			btnNewButton.setBounds(10, 62, 635, 66);
		}
		return btnNewButton;
	}
}
