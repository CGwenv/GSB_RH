package com.persistance;

import java.sql.*;

public class AccesBD {
	protected static Connection con = null;
	public static Connection getInstance() {;
		if (con == null) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost/gsb_rhpst?verifyServerCertificate=false&useSSL=true&serverTimezone=UTC", "myroot", "root123*");
			}

			catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
				System.out.println("échec driver");
			}

			catch (SQLException e){
				System.out.println(e.getMessage());
				System.out.println("échec de connexion bd ");
			}
		}
		return con;
	}

	public static void close() {
		try {
			con.close();
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("problème lors de la fermeture");
		}
	}
}
