package com.persistance;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.metier.Etat;
import com.metier.FicheFrais;
import com.metier.FraisForfait;
import com.metier.LigneFraisForfait;
import com.metier.LigneFraisHorsForfait;
import com.metier.Region;
import com.metier.TypeUtilisateur;
import com.metier.Utilisateur;
import com.metier.Visiteur;
import com.vue.PanelDelVis;

public class AccesData {
	private static Session s = HibernateSession.getSession();
	
	/**
	 * Fonction qui retourne une liste des Regions
	 * @return Liste des regions
	 */
	@SuppressWarnings("unchecked")
	public static List<Region> retrieveRegion() {
		return s.createQuery("from Region").list();
	}
	
	/**
	 * Fonction qui retourne une liste des FraisForfait
	 * @return Liste des FraisForfait
	 */
	@SuppressWarnings("unchecked")
	public static List<FraisForfait> retrieveFraisForfait() {
		return s.createQuery("from FraisForfait").list();
	}
	
	/**
	 * Fonction qui retourne une liste des TypeUtilisateur
	 * @return Liste des TypeUtilisateur
	 */
	@SuppressWarnings("unchecked")
	public static List<TypeUtilisateur> retrieveTypeUtilisateur() {
		return s.createQuery("from TypeUtilisateur").list();
	}
	
	
	@SuppressWarnings("unchecked")
	public static List<Etat> retrieveEtat() {
		return s.createQuery("from Etat").list();
	}

	@SuppressWarnings("unchecked")
	public static List<FicheFrais> retrieveFicheFrais() {
		return s.createQuery("from FicheFrais").list();
	}

	@SuppressWarnings("unchecked")
	public static List<Utilisateur> retrieveUtilisateur() {
		return s.createQuery("from Utilisateur").list();
	}
	
	/**
	 * Fonction qui retourne un Utilisateur
	 * @param login Login d'un utilisateur sous la forme d'une chaine
	 * @param mdp MDP d'un utilisateur sous la forme d'une chaine
	 * @return Utilisateur
	 */
	public static Utilisateur getUtilisateur(String login, String mdp) {
		Query<?> q = s.createQuery("from Utilisateur where login = :login AND mdp = :mdp");
	    q.setParameter("login", login);
	    q.setParameter("mdp", mdp);

	    return (Utilisateur) q.uniqueResult();
	}
	
	public static Visiteur retriveVisiteurByID(String id) {
		Query<?> q = s.createQuery("from Visiteur where id = :id");
	    q.setParameter("id", id);

	    return (Visiteur) q.uniqueResult();
	}
	
	public static void removeVisiteurByID(String id) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		try{
			cstm = cnx.prepareCall("DELETE FROM Visiteur WHERE idVisiteur = ?");
			cstm.setString(1, id);
			cstm.executeUpdate();
			JOptionPane.showMessageDialog(null, "Le visiteur '" + id + "' a bien été supprimé !", "Suppresion OK", JOptionPane.INFORMATION_MESSAGE);
		}catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
			JOptionPane.showMessageDialog(null, e.getLocalizedMessage(), "Erreur de suppresion", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public static void updateVisiteur(String id, String adr, String cp, String ville, String telFixe, String telPort, int idRegion) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		try{
			cstm = cnx.prepareCall("UPDATE visiteur SET adresse = ?, cp = ?, ville = ?, telFixe = ?, telPortable = ?, idRegion = ? WHERE idVisiteur = ?");
			cstm.setString(1, adr);
			cstm.setString(2, cp);
			cstm.setString(3, ville);
			cstm.setString(4, telFixe);
			cstm.setString(5, telPort);
			cstm.setInt(6, idRegion);
			cstm.setString(7, id);
			cstm.executeUpdate();
		} catch (Exception e) {}
	}
	
	public static List<Object[]> getVisiteurRegion(int idRegion) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		ResultSet rs = null;
		List<Object[]> liste=new ArrayList<Object[]>();
		try {
			cstm = cnx.prepareCall("{call ListeVisiteurParRegion(?)}");
			cstm.setInt(1, idRegion);
			rs = cstm.executeQuery();
			while (rs.next()) {
				Object[] data = new Object[3];
				data[0] = rs.getString(1);
				data[1] = rs.getString(2);
				data[2] = rs.getString(3);
				liste.add(data);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
}
	
	public static List<Object[]> getVisiteurNomPrenom(String nom, String prenom) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		ResultSet rs = null;
		List<Object[]> liste=new ArrayList<Object[]>();
		try {
			cstm = cnx.prepareCall("{call ListeVisiteurParNomPrenom(?,?)}");
			cstm.setString(1, nom);
			cstm.setString(2, prenom);
			rs = cstm.executeQuery();
			while (rs.next()) {
				Object[] data = new Object[3];
				data[0] = rs.getString(1);
				data[1] = rs.getString(2);
				data[2] = rs.getString(3);
				liste.add(data);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
}
	
	public static List<Object[]> getVisiteurID(String id) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		ResultSet rs = null;
		List<Object[]> liste=new ArrayList<Object[]>();
		try {
			cstm = cnx.prepareCall("{call ListeVisiteurParID(?)}");
			cstm.setString(1, id);
			rs = cstm.executeQuery();
			while (rs.next()) {
				Object[] data = new Object[3];
				data[0] = rs.getString(1);
				data[1] = rs.getString(2);
				data[2] = rs.getString(3);
				liste.add(data);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
}
	
	public static List<Object[]> getVisiteur() {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		ResultSet rs = null;
		List<Object[]> liste=new ArrayList<Object[]>();
		try {
			cstm = cnx.prepareCall("{call ListeVisiteur()}");
			rs = cstm.executeQuery();
			while (rs.next()) {
				Object[] data = new Object[3];
				data[0] = rs.getString(1);
				data[1] = rs.getString(2);
				data[2] = rs.getString(3);
				liste.add(data);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
}
	
	@SuppressWarnings("unchecked")
	public static List<Visiteur> retrieveVisiteur() {
		return s.createQuery("from Visiteur").list();
	}

	@SuppressWarnings("unchecked")
	public static List<LigneFraisHorsForfait> retrieveLigneFraisHorsForfait() {
		return s.createQuery("from LigneFraisHorsForfait").list();
	}
	
	@SuppressWarnings("unchecked")
	public static List<LigneFraisForfait> retrieveLigneFraisForfait() {
		return s.createQuery("from LigneFraisForfait").list();
	}
	
	public static List<Object[]> GetStatFicheHF(int idRegion, String mois) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		ResultSet rs = null;
		List<Object[]> liste=new ArrayList<Object[]>();
		try {
			cstm = cnx.prepareCall("{call NbFicheFraisHorsForfaitRegionMois(?, ?)}");
			cstm.setString(1, mois);
            cstm.setInt(2, idRegion);
			rs = cstm.executeQuery();
			while (rs.next()) {
				Object[] data = new Object[4];
				data[0] = rs.getString(1);
				data[1] = rs.getString(2);
				data[2] = rs.getString(3);
				data[3] = rs.getInt(4);
				liste.add(data);
				System.out.println(data);
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
}

	public static List<Object[]> GetTotalFicheHF(int idRegion, String mois) {
		Connection cnx=AccesBD.getInstance();
		CallableStatement cstm;
		ResultSet rs = null;
		List<Object[]> liste=new ArrayList<Object[]>();
		try {
			cstm = cnx.prepareCall("{call TotalFraisHorsForfaitRegionMois(?, ?)}");
			cstm.setString(1, mois);
            cstm.setInt(2, idRegion);
			rs = cstm.executeQuery();
			while (rs.next()) {
				Object[] data = new Object[4];
				data[0] = rs.getString(1);
				data[1] =rs.getString(2);
				data[2] = rs.getString(3);
				data[3] = rs.getInt(4);
				liste.add(data);
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return liste;
}

}
