package com.metier;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="typeutilisateur")
public class TypeUtilisateur {
	@Id
	@Column(name="idTypeUtilisateur")
    private String idTypeUtilisateur;
	@Column(name="libelleTypeUtilisateur")
    private String libelleTypeUtilisateur;
	
	public TypeUtilisateur() {
		super();
	}
	
	public TypeUtilisateur(String idTypeUtilisateur, String libelleTypeUtilisateur) {
		this.idTypeUtilisateur = idTypeUtilisateur;
		this.libelleTypeUtilisateur = libelleTypeUtilisateur;
	}

	public String getIdTypeUtilisateur() {
		return idTypeUtilisateur;
	}

	public void setIdTypeUtilisateur(String idTypeUtilisateur) {
		this.idTypeUtilisateur = idTypeUtilisateur;
	}

	public String getLibelleTypeUtilisateur() {
		return libelleTypeUtilisateur;
	}

	public void setLibelleTypeUtilisateur(String libelleTypeUtilisateur) {
		this.libelleTypeUtilisateur = libelleTypeUtilisateur;
	}

	@Override
	public String toString() {
		return "TypeUtilisateur [idTypeUtilisateur=" + idTypeUtilisateur + ", libelleTypeUtilisateur="
				+ libelleTypeUtilisateur + "]";
	}
}
