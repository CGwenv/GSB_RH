package com.metier;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="visiteur")
public class Visiteur {
	@Id
	@Column(name="idVisiteur")
    private String idVisiteur;
	@Column(name="nom")
    private String nom;
	@Column(name="prenom")
    private String prenom;
	@Column(name="login")
    private String login;
	@Column(name="mdp")
    private String mdp;
	@Column(name="adresse")
    private String adresse;
	@Column(name="cp")
    private String cp;
	@Column(name="ville")
    private String ville;
	@Column(name="dateEmbauche")
    private Date dateEmbauche;
	@Column(name="email")
    private String email;
	@Column(name="telFixe")
    private String telFixe;
	@Column(name="telPortable")
    private String telPortable;
	
	@ManyToOne
	@JoinColumn(name="idRegion")
	private Region laRegion;
	
	public Visiteur() {
		super();
	}
	
	public Visiteur(String idVisiteur, String nom, String prenom, String login, String mdp, String adresse,
			String cp, String ville, Date dateEmbauche, String email, String telFixe, String telPortable, Region laRegion) {
		super();
		this.idVisiteur = idVisiteur;
		this.nom = nom;
		this.prenom = prenom;
		this.login = login;
		this.mdp = mdp;
		this.adresse = adresse;
		this.cp = cp;
		this.ville = ville;
		this.dateEmbauche = dateEmbauche;
		this.email = email;
		this.telFixe = telFixe;
		this.telPortable = telPortable;
		this.laRegion = laRegion;
	}



	public String getidVisiteur() {
		return idVisiteur;
	}
	public void setidVisiteur(String idVisiteur) {
		this.idVisiteur = idVisiteur;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMdp() {
		return mdp;
	}
	public void setMdp(String mdp) {
		this.mdp = mdp;
	}
	public String getAdresse() {
		return adresse;
	}
	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}
	public String getCp() {
		return cp;
	}
	public void setCp(String cp) {
		this.cp = cp;
	}
	public String getVille() {
		return ville;
	}
	public void setVille(String ville) {
		this.ville = ville;
	}
	public Date getDateEmbauche() {
		return dateEmbauche;
	}
	public void setDateEmbauche(Date dateEmbauche) {
		this.dateEmbauche = dateEmbauche;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelFixe() {
		return telFixe;
	}
	public void setTelFixe(String telFixe) {
		this.telFixe = telFixe;
	}
	public String getTelPortable() {
		return telPortable;
	}
	
	public int getIDRegion() {
		return laRegion.getIdRegion();
	}
	
	public void setIDRegion(Region r) {
		this.laRegion = r;
	}
	
	public void setTelPortable(String telPortable) {
		this.telPortable = telPortable;
	}
	
	@Override
	public String toString() {
		return "Utilisateur [idVisiteur=" + idVisiteur + ", nom=" + nom + ", prenom=" + prenom + ", login="
				+ login + ", mdp=" + mdp + ", adresse=" + adresse + ", cp=" + cp + ", ville=" + ville
				+ ", dateEmbauche=" + dateEmbauche + ", email=" + email
				+ ", telFixe=" + telFixe + ", telPortable=" + telPortable + ", laRegion=" + laRegion + "]";
	}
}
