package com.metier;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="lignefraisforfait")
//lien vers la classe LigneFraisForfaitPK qui gére la clé primaire
@IdClass(LigneFraisForfaitPK.class)
@Embeddable
public class LigneFraisForfait implements java.io.Serializable {
	
	@Id
	@Column(name="idVisiteur")
    private String idVisiteur;
	@Id
	@Column(name="mois")
    private String mois;
	@Id
	@Column(name = "idFraisForfait", insertable = false, updatable = false)
	private String idFraisForfait;
	@ManyToOne
	@JoinColumn(name = "idFraisForfait")
	private FraisForfait fraisForfait;
	@Column(name="quantite")
    private int quantite;
	
	public LigneFraisForfait() {
		super();
	}
	
	public LigneFraisForfait(String idVisiteur, String mois, String idFraisForfait, FraisForfait fraisForfait,
			int quantite) {
		this.idVisiteur = idVisiteur;
		this.mois = mois;
		this.idFraisForfait = idFraisForfait;
		this.fraisForfait = fraisForfait;
		this.quantite = quantite;
	}

	public String getIdVisiteur() {
		return idVisiteur;
	}

	public void setIdVisiteur(String idVisiteur) {
		this.idVisiteur = idVisiteur;
	}

	public String getMois() {
		return mois;
	}

	public void setMois(String mois) {
		this.mois = mois;
	}

	public String getIdFraisForfait() {
		return idFraisForfait;
	}

	public void setIdFraisForfait(String idFraisForfait) {
		this.idFraisForfait = idFraisForfait;
	}

	public FraisForfait getFraisForfait() {
		return fraisForfait;
	}

	public void setFraisForfait(FraisForfait fraisForfait) {
		this.fraisForfait = fraisForfait;
	}

	public int getQuantite() {
		return quantite;
	}

	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}

	@Override
	public String toString() {
		return "LigneFraisForfait [idVisiteur=" + idVisiteur + ", mois=" + mois + ", idFraisForfait=" + idFraisForfait
				+ ", fraisForfait=" + fraisForfait + ", quantite=" + quantite + "]";
	}
}
