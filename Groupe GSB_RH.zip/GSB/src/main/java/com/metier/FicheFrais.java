package com.metier;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "fichefrais")
// lien vers la classe FicheFraisPK qui gére la clé primaire
@IdClass(FicheFraisPK.class)
@Embeddable
public class FicheFrais implements Serializable {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// propriétés idVisiteur et mois composant de l'id
	@Id
	@Column(name = "idVisiteur")
	private String idVisiteur;
	@Id
	@Column(name = "mois")
	private String mois;
	@Column(name = "nbJustificatifs")
	private int nb;
	@ManyToOne
	@JoinColumn(name = "idVisiteur", insertable = false, updatable = false)
	private Visiteur leVisiteur;
	@ManyToOne
	@JoinColumn(name = "idEtat")
	private Etat etat;
// mapping pour mise en place de l'association vers listeHF
// listeHF pour le visiteur identifié par idVisiteur, mois
	@OneToMany
	@JoinColumns({ @JoinColumn(name = "idVisiteur", insertable = false, updatable = false),
			@JoinColumn(name = "mois", insertable = false, updatable = false) })
	private List<LigneFraisHorsForfait> listeHF;
	@OneToMany
	@JoinColumns({ @JoinColumn(name = "idVisiteur", insertable = false, updatable = false),
			@JoinColumn(name = "mois", insertable = false, updatable = false) })
	private List<LigneFraisForfait> listeFF;

// constructeur vide
	public FicheFrais() {
		super();
	}

	public List<LigneFraisForfait> getListeFF() {
		return listeFF;
	}

	public void setListeFF(List<LigneFraisForfait> listeFF) {
		this.listeFF = listeFF;
	}

	public List<LigneFraisHorsForfait> getListeHF() {
		return listeHF;
	}

	public void setListeHF(List<LigneFraisHorsForfait> listeHF) {
		this.listeHF = listeHF;
	}

	public Etat getEtat() {
		return etat;
	}

	public void setEtat(Etat etat) {
		this.etat = etat;
	}

	public Visiteur getLeVisiteur() {
		return leVisiteur;
	}

	public void setLeVisiteur(Visiteur leVisiteur) {
		this.leVisiteur = leVisiteur;
	}

	public String getIdVisiteur() {
		return idVisiteur;
	}

	public void setIdVisiteur(String idVisiteur) {
		this.idVisiteur = idVisiteur;
	}

	public String getMois() {
		return mois;
	}

	public void setMois(String mois) {
		this.mois = mois;
	}

	public int getNb() {
		return nb;
	}

	public void setNb(int nb) {
		this.nb = nb;
	}

	@Override
	public String toString() {
		return "FicheFrais [idVisiteur=" + idVisiteur + ", mois=" + mois + ", nb=" + nb + ", leVisiteur=" + leVisiteur
				+ ", etat=" + etat + ", listeHF=" + listeHF + ", listeFF=" + listeFF + "]";
	}
	
}