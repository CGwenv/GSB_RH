package com.metier;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="fraisforfait")
public class FraisForfait  {
	@Id
	@Column(name="idFraisForfait")
    private String idFraisForfait;
	@Column(name="libelleFraisForfait")
    private String libelleFraisForfait;
	@Column(name="montant")
    private double montant;
	
	public FraisForfait() {
		super();
	}
	
	public FraisForfait(String idFraisForfait, String libelleFraisForfait, double montant) {
		this.idFraisForfait = idFraisForfait;
		this.libelleFraisForfait = libelleFraisForfait;
		this.montant = montant;
	}

	public String getIdFraisForfait() {
		return idFraisForfait;
	}

	public void setIdFraisForfait(String idFraisForfait) {
		this.idFraisForfait = idFraisForfait;
	}

	public String getLibelleFraisForfait() {
		return libelleFraisForfait;
	}

	public void setLibelleFraisForfait(String libelleFraisForfait) {
		this.libelleFraisForfait = libelleFraisForfait;
	}

	public double getMontant() {
		return montant;
	}

	public void setMontant(double montant) {
		this.montant = montant;
	}

	@Override
	public String toString() {
		return "FraisForfait [idFraisForfait=" + idFraisForfait + ", libelleFraisForfait=" + libelleFraisForfait
				+ ", montant=" + montant + "]";
	}
}
