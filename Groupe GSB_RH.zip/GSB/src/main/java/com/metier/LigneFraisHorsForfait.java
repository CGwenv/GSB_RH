package com.metier;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="lignefraishorsforfait")
public class LigneFraisHorsForfait implements Serializable {
	@Id
	@Column(name="idVisiteur")
    private String idVisiteur;
	@Id
	@Column(name="mois")
    private String mois;
	@Id
	@Column(name = "idFraisHorsForfait")
	private int idFraisHorsForfait;
	
	@Column(name="libelleFraisHorsForfait")
    private String libelleFraisHorsForfait;
	
	@Column(name="date")
    private Date date;
	
	@Column(name="montant")
    private double montant;
	
	public LigneFraisHorsForfait() {
		super();
	}

	public LigneFraisHorsForfait(String idVisiteur, String mois, int idFraisHorsForfait,
			String libelleFraisHorsForfait, Date date, double montant) {
		super();
		this.idVisiteur = idVisiteur;
		this.mois = mois;
		this.idFraisHorsForfait = idFraisHorsForfait;
		this.libelleFraisHorsForfait = libelleFraisHorsForfait;
		this.date = date;
		this.montant = montant;
	}

	public String getIdVisiteur() {
		return idVisiteur;
	}

	public void setIdVisiteur(String idVisiteur) {
		this.idVisiteur = idVisiteur;
	}

	public String getMois() {
		return mois;
	}

	public void setMois(String mois) {
		this.mois = mois;
	}

	public int getIdFraisHorsForfait() {
		return idFraisHorsForfait;
	}

	public void setIdFraisHorsForfait(int idFraisHorsForfait) {
		this.idFraisHorsForfait = idFraisHorsForfait;
	}


	public String getLibelleFraisHorsForfait() {
		return libelleFraisHorsForfait;
	}

	public void setLibelleFraisHorsForfait(String libelleFraisHorsForfait) {
		this.libelleFraisHorsForfait = libelleFraisHorsForfait;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public double getMontant() {
		return montant;
	}

	public void setMontant(double montant) {
		this.montant = montant;
	}

	@Override
	public String toString() {
		return "LigneFraisHorsForfait [idVisiteur=" + idVisiteur + ", mois=" + mois + ", idFraisHorsForfait="
				+ idFraisHorsForfait + ", libelleFraisHorsForfait="
				+ libelleFraisHorsForfait + ", date=" + date + ", montant=" + montant + "]";
	}
	
	
	
	
}
