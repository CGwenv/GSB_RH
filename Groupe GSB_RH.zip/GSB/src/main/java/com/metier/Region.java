package com.metier;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="region")
public class Region {
	@Id
	@Column(name="idRegion")
    private int idRegion;
	@Column(name="nomRegion")
    private String nomRegion;
	
	public Region() {
		super();
	}
	
	public Region(int idRegion, String nomRegion) {
		this.idRegion = idRegion;
		this.nomRegion = nomRegion;
	}

	public int getIdRegion() {
		return idRegion;
	}

	public void setIdRegion(int idRegion) {
		this.idRegion = idRegion;
	}

	public String getNomRegion() {
		return nomRegion;
	}

	public void setNomRegion(String nomRegion) {
		this.nomRegion = nomRegion;
	}

	@Override
	public String toString() {
		return "Region [idRegion=" + idRegion + ", nomRegion=" + nomRegion + "]";
	}
	
}
