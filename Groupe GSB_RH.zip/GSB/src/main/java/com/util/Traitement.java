package com.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import com.persistance.AccesBD;
import com.persistance.AccesData;

public class Traitement {

	public static void getFicheFrais() {
		CallableStatement cstm;
		Connection cnxPS=AccesBD.getInstance();
		try {
			cstm=cnxPS.prepareCall("{call ListeFraisForfait()}");
			ResultSet rsPS = cstm.executeQuery();
			System.out.println("");
			System.out.println("██████████ LISTE FRAIS FORFAIT ██████████");
			System.out.println("█                                       █");
			while(rsPS.next()) {
				System.out.println("█        " + rsPS.getString("idFraisForfait") + " " + rsPS.getString("libelleFraisForfait"));
			}
			System.out.println("█                                       █");
			System.out.println("█████████████████████████████████████████");
			System.out.println("");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void getEtatFicheVisiteur() {
		CallableStatement cstm;
		Connection cnxPS=AccesBD.getInstance();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Donner l'id d'un visiteur :");
		String idVisiteur = scanner.nextLine();
		try {
			cstm=cnxPS.prepareCall("{call EtatFicheVisiteur(?)}");
			cstm.setString(1, idVisiteur);
			ResultSet rsPS = cstm.executeQuery();
			System.out.println("");
			System.out.println("████████████████ ETAT FICHE PAR VISITEUR ████████████████");
			System.out.println("█                                                       █");
			while(rsPS.next()) {
				System.out.println("█      idVisiteur : " + rsPS.getString("idVisiteur") + "  Mois : " + rsPS.getString("mois") + "  Etat : " + rsPS.getString("idEtat") + "      █");
			}
			System.out.println("█                                                       █");
			System.out.println("█████████████████████████████████████████████████████████");
			System.out.println("");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void getNbFicheFraisVisiteur() {
		CallableStatement cstm;
		Connection cnxPS=AccesBD.getInstance();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Donner l'id d'un visiteur :");
		String idVisiteur = scanner.nextLine();
		try {
			cstm=cnxPS.prepareCall("{call NbFicheFraisVisiteur(?, ?)}");
			cstm.setString(1, idVisiteur);
			cstm.registerOutParameter(2, java.sql.Types.INTEGER); 
			System.out.println("");
			System.out.println("█████████████ NOMBRE FICHE PAR VISITEUR █████████████");
			System.out.println("█                                                   █");
			System.out.println("█       idVisiteur : " + idVisiteur + "  Nombre de fiche : " + cstm.getInt(2) + "      █");
			System.out.println("█                                                   █");
			System.out.println("█████████████████████████████████████████████████████");
			System.out.println("");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void getSuppVisiteur() {
		CallableStatement cstm;
		Connection cnxPS=AccesBD.getInstance();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Donner l'id d'un visiteur :");
		String idVisiteur = scanner.nextLine();

		String sql = "delete from utilisateur where idUtilisateur=" + idVisiteur;

		try {

		      Statement stm = cnxPS.createStatement();

		      int nb = stm.executeUpdate(sql);

		      System.out.println(nb + "suppression");

		      } catch (SQLException e1) {

		      // on affiche le code erreur

		            System.out.println(e1.getErrorCode());

		            // on affiche le message prévu dans le trigger

		            System.out.println(e1.getMessage());

		            }
	}
	
	public static void getStatFicheHF() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Donner un mois (ex: 202103) :");
		String mois = scanner.nextLine();
		System.out.println("Donner un id de region (ex: 2 - Centre) :");
		int idRegion = scanner.nextInt();
		List<Object[]> liste = AccesData.GetStatFicheHF(idRegion, mois);
	
			System.out.println("");
			System.out.println("█████████████ STAT FICHE HORS FORFAIT PAR MOIS ET REGION █████████████");
			System.out.println("█                                                                    █");
		  for(Object[] obj : liste) { 
			  System.out.println("█       " + obj[0] + "  " + obj[1] + "  "  + obj[2] + "  " + obj[3] + "       ");
		  }
			System.out.println("█                                                                    █");
			System.out.println("██████████████████████████████████████████████████████████████████████");
			System.out.println("");
	}
	
	public static void getTotalFicheHF() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Donner un mois (ex: 202103) :");
		String mois = scanner.nextLine();
		System.out.println("Donner un id de region (ex: 2 - Centre) :");
		int idRegion = scanner.nextInt();
		List<Object[]> liste = AccesData.GetTotalFicheHF(idRegion, mois);
	
			System.out.println("");
			System.out.println("████ TOTAL FICHE HORS FORFAIT PAR MOIS ET REGION ████");
			System.out.println("█                                                   █");
		  for(Object[] obj : liste) { 
			  System.out.println("█       " + obj[0] + "  " + obj[1] + "  "  + obj[2] + "  " + obj[3] + "       ");
		  }
			System.out.println("█                                                   █");
			System.out.println("█████████████████████████████████████████████████████");
			System.out.println("");
	}
}
