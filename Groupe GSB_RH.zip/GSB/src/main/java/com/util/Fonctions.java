package com.util;

import org.apache.commons.lang3.RandomStringUtils;

public class Fonctions {

	private static String mail;
	private static String login;
	
	public static String create_mail(String nom, String prenom) {
		mail = nom.toLowerCase() + "." + prenom.toLowerCase() + "@gsb.fr";
		return mail;
	}
	
	public static String create_login(String nom, String prenom) {
		char prenomC = prenom.charAt(0);
		login = Character.toLowerCase(prenomC) + nom.toLowerCase();
		return login;
	}
	
	public static String create_mdp() {
		String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789~`!@#$%^&*()-_=+[{]}\\|;:\'\",<.>/?";
		String pwd = RandomStringUtils.random( 8, characters );
		return pwd;
	}
}
